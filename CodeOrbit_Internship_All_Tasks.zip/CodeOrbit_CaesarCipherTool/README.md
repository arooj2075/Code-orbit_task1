# CodeOrbit_CaesarCipherTool
Python program that encrypts and decrypts text with the Caesar Cipher using a user-chosen shift (key). Shows encrypted and decrypted output.
Run: `python caesar_cipher.py`
