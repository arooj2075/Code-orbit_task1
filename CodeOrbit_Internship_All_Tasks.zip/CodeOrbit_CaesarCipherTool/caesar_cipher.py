"""
CodeOrbit Tech - Cyber Security Internship
Task 2: Caesar Cipher Encryption Tool
Encrypts and decrypts text with a user-chosen shift (key).
"""


def shift_text(text, key):
    """Shift letters by `key` positions. Non-letters are left unchanged."""
    result = ""
    for ch in text:
        if ch.isupper():
            result += chr((ord(ch) - ord("A") + key) % 26 + ord("A"))
        elif ch.islower():
            result += chr((ord(ch) - ord("a") + key) % 26 + ord("a"))
        else:
            result += ch
    return result


def encrypt(text, key):
    return shift_text(text, key)


def decrypt(text, key):
    return shift_text(text, -key)


def get_key():
    while True:
        try:
            return int(input("Enter shift value (key, e.g. 3): ")) % 26
        except ValueError:
            print("Please enter a whole number.")


def main():
    print("=" * 45)
    print("   CAESAR CIPHER TOOL")
    print("=" * 45)

    while True:
        print("\n1. Encrypt a message")
        print("2. Decrypt a message")
        print("3. Demo (encrypt then decrypt)")
        print("4. Quit")
        choice = input("Choose an option (1-4): ").strip()

        if choice == "1":
            text = input("Enter text to encrypt: ")
            key = get_key()
            print(f"\nOriginal : {text}")
            print(f"Encrypted: {encrypt(text, key)}")
        elif choice == "2":
            text = input("Enter text to decrypt: ")
            key = get_key()
            print(f"\nEncrypted: {text}")
            print(f"Decrypted: {decrypt(text, key)}")
        elif choice == "3":
            text = input("Enter text: ")
            key = get_key()
            enc = encrypt(text, key)
            dec = decrypt(enc, key)
            print(f"\nOriginal : {text}")
            print(f"Key      : {key}")
            print(f"Encrypted: {enc}")
            print(f"Decrypted: {dec}")
        elif choice == "4":
            print("Goodbye! Stay secure.")
            break
        else:
            print("Invalid option, try again.")


if __name__ == "__main__":
    main()
