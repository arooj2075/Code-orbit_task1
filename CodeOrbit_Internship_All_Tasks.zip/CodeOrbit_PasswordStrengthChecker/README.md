# CodeOrbit_PasswordStrengthChecker
Python script that rates a password as WEAK / MEDIUM / STRONG (length, upper/lowercase, numbers, special characters) and tells the user how to improve it. No external libraries.
Run: `python password_checker.py`
