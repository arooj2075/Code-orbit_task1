"""
CodeOrbit Tech - Cyber Security Internship
Task 1: Password Strength Checker
Uses only basic string operations (no external libraries).
"""

SPECIAL_CHARS = "!@#$%^&*()-_=+[]{};:'\",.<>/?\\|`~"
COMMON_PASSWORDS = {"password", "123456", "12345678", "qwerty", "abc123",
                    "letmein", "welcome", "admin", "iloveyou", "password1"}


def check_password(password):
    """Return (score, max_score, list_of_tips)."""
    tips = []
    score = 0

    # 1. Length
    if len(password) >= 12:
        score += 2
    elif len(password) >= 8:
        score += 1
        tips.append("Use 12 or more characters for a much stronger password.")
    else:
        tips.append("Make your password at least 8 characters long (12+ is best).")

    # 2. Lowercase
    if any(c.islower() for c in password):
        score += 1
    else:
        tips.append("Add lowercase letters (a-z).")

    # 3. Uppercase
    if any(c.isupper() for c in password):
        score += 1
    else:
        tips.append("Add uppercase letters (A-Z).")

    # 4. Digits
    if any(c.isdigit() for c in password):
        score += 1
    else:
        tips.append("Add numbers (0-9).")

    # 5. Special characters
    if any(c in SPECIAL_CHARS for c in password):
        score += 1
    else:
        tips.append("Add special characters such as ! @ # $ % &.")

    # 6. Common password / repeated characters
    if password.lower() in COMMON_PASSWORDS:
        score = min(score, 1)
        tips.append("This is a very common password - avoid it completely.")
    elif len(set(password)) <= 3 and len(password) > 0:
        tips.append("Avoid repeating the same few characters.")
        score = max(score - 1, 0)

    return score, 6, tips


def rating(score):
    if score <= 3:
        return "WEAK"
    if score <= 5:
        return "MEDIUM"
    return "STRONG"


def main():
    print("=" * 45)
    print("   PASSWORD STRENGTH CHECKER")
    print("=" * 45)
    print("Type 'quit' to exit.\n")

    while True:
        pwd = input("Enter a password to check: ")
        if pwd.lower() == "quit":
            print("Goodbye! Stay secure.")
            break
        if pwd == "":
            print("Please enter a password.\n")
            continue

        score, max_score, tips = check_password(pwd)
        result = rating(score)
        print(f"\nStrength: {result}  (score {score}/{max_score})")

        if tips:
            print("How to improve:")
            for t in tips:
                print(f"  - {t}")
        else:
            print("Great job! Your password meets all the checks.")
        print()


if __name__ == "__main__":
    main()
